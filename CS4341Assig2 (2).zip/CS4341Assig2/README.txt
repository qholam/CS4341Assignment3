-COMPILING-
This project can be compiled by Using Eclipse.Import the unzipped 
CS4341Assignment2 folder into Eclipse as an Eclipse project. 

-RUNNING-
Using eclipse, run this project by executing the _.java file.


-NOTES-
There is a tuning.txt file include that explains how we choose
the temperature schedules for the simulated annealing and genetic
algorithm searches. The genetic algorithim does not fully work. Because
of this we could not get data for it in the tuning.txt or the excel 
file with all the data on performances. 