
public class Node {
	int[][] bins;
	int score;

	public Node(int[][] bins, int score) {
		this.bins = bins;
		this.score = score;
	}
}
