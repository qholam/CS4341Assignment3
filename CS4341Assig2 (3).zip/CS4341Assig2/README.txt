-COMPILING-
This project can be compiled by Using Eclipse.Import the unzipped 
CS4341Assignment2 folder into Eclipse as an Eclipse project. 

-RUNNING-
Using eclipse, run this project by executing the _.java file.4

Once executed, you will be prompted to enter the type of search. Enter one
of the following options: 
	"hill" for hill climbing
	"annealing" for simulated annealing
	"ga" for genetic algorthim

You will then be prompted to enter a filename. This file must be saved
in the CS434Assignment2 folder. We have provided a file "test" that can
be used. This file has 150 numbers, so each bin will have 50 numbers. This 
will be sufficient to measure the performance of the searches.

You will then be prompted to enter a time in seconds. 

After entering the above 3 things, the program will run the search and then
print out the set up of the bins and the total score. 

-NOTES-
There is a tuning.txt file include that explains how we choose
the temperature schedules for the simulated annealing and genetic
algorithm searches. 

