import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class ga {
	public static Bins gaSearch(ArrayList<Bins> population, int runTime, double elitism) {
		long endTime = System.currentTimeMillis() + runTime;

		while (System.currentTimeMillis() < endTime) {
			// sort population by fitness (sorts from highest score to lowest
			// score)
			population = sortByFitness(population);

			// choose elites to preserve top 20% for now
			ArrayList<Bins> elites = new ArrayList<Bins>(population.subList(0, (int) (elitism * population.size())));

			ArrayList<Bins> newPopulation = new ArrayList<Bins>();

			for (int i = 0; i < population.size(); i++) {
				Bins x = randomSelection(population);
				Bins y = randomSelection(population);

				// x and y will produce a child
				Bins child = reproduce(x, y);

				// mutate child by swapping two random numbers
				int a = 0 + (int) (Math.random() * child.bins.length);
				int b = 0 + (int) (Math.random() * child.bins[0].length);
				int c = 0 + (int) (Math.random() * child.bins.length);
				int d = 0 + (int) (Math.random() * child.bins[0].length);
				int temp = child.bins[a][b];
				// swap to numbers
				child.bins[a][b] = child.bins[c][d];
				child.bins[c][d] = temp;

				newPopulation.add(child);
			}

			// new population is the preserved list and the new population which
			// consists of the children
			population = new ArrayList<Bins>();
			population.addAll(elites);
			population.addAll(newPopulation);
		}

		// first element should be best arrangement of bins
		sortByFitness(population);
		return population.get(0);
	}

	public static Bins reproduce(Bins x, Bins y) {
		// swap some elements between x and y to produce a child
		int[][] a = x.bins;
		// check if it is still valid(i.e. has some numbers as x and y, just in
		// different order)
		for (int i = 0; i < x.bins.length; i++) {
			int[] array = x.bins[i];
			for (int j = 0; j < x.bins[0].length; j++) {
	            // Get a random index of the array past i.
	            int random = (int) (Math.random() * array.length);
	            // Swap the random element with the present element.
	            int randomElement = array[random];
	            array[random] = array[j];
	            array[j] = randomElement;
	        }
		}

		// Make child
		Bins child = new Bins(a);
		child.score = child.calBins(a);

		return child;
	}

	public static Bins randomSelection(ArrayList<Bins> population) {
		int Max = population.size()/8;
		int randNum = (int) (Max * Math.random());
		System.out.println(Max);
		Bins random = population.get(randNum);

		return random;
	}

	protected static ArrayList<Bins> sortByFitness(ArrayList<Bins> pop) {
		ArrayList<Bins> temp = new ArrayList<Bins>();
		int tempScore;

		for (int i = 0; i < pop.size(); i++) {
			Bins thisBin = pop.get(i);
			tempScore = thisBin.calBins(thisBin.bins);
			thisBin.score = tempScore;

			if (temp.isEmpty()) {
				temp.add(thisBin);
			} else {
				for (int j = 0; j < temp.size(); j++) {
					Bins jBin = temp.get(j);
					if (thisBin.score > jBin.score) {
						temp.add(j, thisBin);
					} else if (thisBin.score <= jBin.score) {
						continue;
					}
				}
			}
		}

		return temp;
	}
}
